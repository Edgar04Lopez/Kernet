# Programa Gratis para Restaurante con Toma de Pedidos y Gestión de Meseros

<img src="https://i0.wp.com/www.configuroweb.com/wp-content/uploads/2020/01/Programa-Gratis-para-Restaurante-con-Toma-de-Pedidos-y-Gestion-de-Meseros-1.jpg?resize=800%2C500&ssl=1">

Restaurante | Web es una aplicación web que gestiona el orden del menú del restaurante entre el perfil mesero y el chef.

## Acceso Admin
Usuario "admin"
Contraseña "1234abcd.."

Para ver los empleados:
Busca en la BD

### Nota
All staff created have same default password : 1234abcd..

Todos los detalles relacionados con la aplicación los puedes encontrar en el siguiente enlace:

https://www.web.com/programa-gratis-para-restaurante-con-toma-de-pedidos-y-gestion-de-meseros/
